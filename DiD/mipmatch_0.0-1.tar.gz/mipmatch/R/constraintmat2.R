.constraintmat = function(t_ind, n_matches,
						  mom_covs, mom_weights, mom_tols,
						  ks_covs, ks_covs_aux, ks_n_grid, ks_weights, ks_tols,
						  exact_covs, 
						  near_exact_covs, near_exact_devs,
						  fine_covs,
						  near_fine_covs, near_fine_devs,
						  use_controls_mat, use_controls_totals, use_controls_signs) {
						 	
	n_t = sum(t_ind)
	n_c = length(t_ind)-n_t	

	n_tot = n_t*n_c
	
	row_ind_1 = sort(rep(1:n_t, n_c))
	col_ind_1 = 1:n_tot
	ones_1 = rep(1, n_tot)
	
	row_ind_2 = sort(rep(1:n_c, n_t))+n_t
	col_ind_2 = rep(seq(1, n_t*n_c, n_c), n_c)+(sort(rep(1:n_c, n_t))-1)
	ones_2 = rep(1, n_tot)
	row_ind_cur	= max(row_ind_2)
	
	mom_ks_covs = NULL
	if (!is.null(mom_covs) | !is.null(ks_covs)) {
		row_ind_3.4 = 0
		n_mom_covs = 0
		if(!is.null(mom_covs)) {
			mom_covs = as.matrix(mom_covs[t_ind==0, ])
			n_mom_covs = ncol(mom_covs)
		}
		n_ks_covs = 0
		if(!is.null(ks_covs)) {
			n_ks_covs = ncol(ks_covs)
		}
		if(!is.null(mom_covs) & is.null(ks_covs_aux)) {
			mom_ks_covs = mom_covs
		}
		if(is.null(mom_covs) & !is.null(ks_covs_aux)) {
			mom_ks_covs = ks_covs_aux
		}
		if(!is.null(mom_covs) & !is.null(ks_covs_aux)) {
			mom_ks_covs = cbind(mom_covs, ks_covs_aux)
		}	
	}					 
	if (!is.null(mom_ks_covs)) {
		n_mom_ks_covs = ncol(mom_ks_covs)
		if (!is.null(mom_weights) | !is.null(ks_weights)) {
			row_ind_3.4 = sort(rep(1:(2*n_mom_ks_covs)+n_t+n_c, n_tot+1))
		}	
		if (!is.null(mom_tols) | !is.null(ks_tols)) {
			row_ind_3.4 = sort(rep(1:(2*n_mom_ks_covs)+n_t+n_c, n_tot))
		}	
		col_ind_3.4 = NA
		mom_ks_vals_3.4 = NA
		j = 1
		k = 0
		for (i in 1:n_mom_ks_covs) {
			if (n_mom_covs != 0 & i <= n_mom_covs) {	
				if (!is.null(mom_weights) | !is.null(ks_weights)) {
					col_ind_3.4 = c(col_ind_3.4, rep(c(1:n_tot, n_tot+i), 2))
				}	
				if (!is.null(mom_tols) | !is.null(ks_tols)) {
					col_ind_3.4 = c(col_ind_3.4, rep(1:n_tot, 2))
				}
			}
			if (n_ks_covs != 0 & i > n_mom_covs) {	
				if (!is.null(mom_weights) | !is.null(ks_weights)) {
					col_ind_3.4 = c(col_ind_3.4, rep(c(1:n_tot, n_tot+n_mom_covs+j), 2))
					k = k+1
					if (k >= ks_n_grid) {
						j = j+1
						k = 0	
					}
				}	
				if (!is.null(mom_tols) | !is.null(ks_tols)) {
					col_ind_3.4 = c(col_ind_3.4, rep(1:n_tot, 2))
					k = k+1
					if (k >= ks_n_grid) {
						j = j+1
						k = 0	
					}
				}
			}
			temp_mean_1 = mom_ks_covs[, i]/(n_matches*n_t)
			if (!is.null(mom_weights) | !is.null(ks_weights)) {
				temp_mean_2 = c(rep(temp_mean_1, n_t), -1)
				temp_mean_3 = c(-rep(temp_mean_1, n_t), -1)
			}	
			if (!is.null(mom_tols) | !is.null(ks_tols)) {
				temp_mean_2 = rep(temp_mean_1, n_t)
				temp_mean_3 = -rep(temp_mean_1, n_t)
			}	
			mom_ks_vals_3.4 = c(mom_ks_vals_3.4, temp_mean_2, temp_mean_3)
			if (i == 1) {
				col_ind_3.4 = col_ind_3.4[-1]
				mom_ks_vals_3.4 = mom_ks_vals_3.4[-1]
			}
		}
		row_ind_cur	= max(row_ind_3.4)
	}	

	if (!is.null(exact_covs)) {
		n_exact_covs = ncol(exact_covs)
		exact_vals_5 = NA
		row_ind_5 = NA
		col_ind_5 = NA
		for (i in 1:n_exact_covs) {	
			exact_vals_5_aux = abs(outer(exact_covs[t_ind==1, i], exact_covs[t_ind==0, i], "-"))
			exact_vals_5_aux = as.vector(t(exact_vals_5_aux))
			row_ind_5_aux = (rep(row_ind_cur+i, n_tot))[exact_vals_5_aux!=0]
			col_ind_5_aux = (1:n_tot)[exact_vals_5_aux!=0]
			exact_vals_5_aux = exact_vals_5_aux[exact_vals_5_aux!=0]
			exact_vals_5 = c(exact_vals_5, exact_vals_5_aux)
			row_ind_5 = c(row_ind_5, row_ind_5_aux)
			col_ind_5 = c(col_ind_5, col_ind_5_aux)
			if (i == 1) {
				exact_vals_5 = exact_vals_5[-1]
				row_ind_5 = row_ind_5[-1]
				col_ind_5 = col_ind_5[-1]		
			}
		}	
		row_ind_cur	= max(row_ind_5)
	}
	
	if (!is.null(near_exact_covs)) {
		n_near_exact_covs = ncol(near_exact_covs)
		near_exact_vals_6 = NA
		row_ind_6 = NA
		col_ind_6 = NA
		for (i in 1:n_near_exact_covs) {
			near_exact_vals_6_aux = abs(outer(near_exact_covs[t_ind==1, i], near_exact_covs[t_ind==0, i], "-"))
			near_exact_vals_6_aux = as.vector(t(near_exact_vals_6_aux))
near_exact_vals_6_aux = (near_exact_vals_6_aux!=0)*1
			row_ind_6_aux = (rep(row_ind_cur+i, n_tot))[near_exact_vals_6_aux!=0]
			col_ind_6_aux = (1:n_tot)[near_exact_vals_6_aux!=0]
			near_exact_vals_6_aux = near_exact_vals_6_aux[near_exact_vals_6_aux!=0]
			near_exact_vals_6 = c(near_exact_vals_6, near_exact_vals_6_aux)
			row_ind_6 = c(row_ind_6, row_ind_6_aux)
			col_ind_6 = c(col_ind_6, col_ind_6_aux)
			if (i == 1) {
				near_exact_vals_6 = near_exact_vals_6[-1]
				row_ind_6 = row_ind_6[-1]
				col_ind_6 = col_ind_6[-1]		
			}
		}
		row_ind_cur	= max(row_ind_6)
	}
	
	bvec_7 = NA
	if (!is.null(fine_covs)) {
		row_ind_7 = NA
		col_ind_7 = NA
		fine_vals_7 = NA
		n_fine_covs = ncol(fine_covs)
		k = 1
		for (j in 1:n_fine_covs) {
			fine_cov = fine_covs[, j]
			bvec_7 = c(bvec_7, as.numeric(table(fine_cov, t_ind)[, 2]))
			cats_fine_covs = as.numeric(names(table(fine_cov)))
			for (i in cats_fine_covs) {			
				fine_cov_aux = rep(0, length(fine_cov[t_ind==0]))
				fine_cov_aux[fine_cov[t_ind==0] == i] = 1
				fine_cov_aux = rep(fine_cov_aux, n_t)
				row_ind_7_aux = (rep(row_ind_cur+k, n_tot))[fine_cov_aux!=0]
				col_ind_7_aux = (1:n_tot)[fine_cov_aux!=0]
				fine_cov_aux = fine_cov_aux[fine_cov_aux!=0]
				row_ind_7 = c(row_ind_7, row_ind_7_aux)
				col_ind_7 = c(col_ind_7, col_ind_7_aux)
				fine_vals_7 = c(fine_vals_7, fine_cov_aux)
				k = k+1	
			}
		}	
		bvec_7 = bvec_7[-1]
		row_ind_7 = row_ind_7[-1]
		col_ind_7 = col_ind_7[-1]
		fine_vals_7 = fine_vals_7[-1]
		row_ind_cur	= max(row_ind_7)
	}
	
	bvec_8 = NA
	vec_n_cats_near_fine_covs = NA
	if (!is.null(near_fine_covs)) {
		row_ind_8 = NA
		col_ind_8 = NA
		near_fine_vals_8 = NA
		n_near_fine_covs = ncol(near_fine_covs)	
		k = 1
		for (j in 1:n_near_fine_covs) {
			near_fine_cov = near_fine_covs[, j]
			bvec_8 = c(bvec_8, as.numeric(table(near_fine_cov, t_ind)[, 2]))
			cats_near_fine_cov = as.numeric(names(table(near_fine_cov)))
			vec_n_cats_near_fine_covs = c(vec_n_cats_near_fine_covs, rep(j, length(cats_near_fine_cov)))
			
			for (i in cats_near_fine_cov) {
				for (h in 1:2) {
					near_fine_cov_aux = rep(0, length(near_fine_cov[t_ind==0]))
					near_fine_cov_aux[near_fine_cov[t_ind==0] == i] = 1
					near_fine_cov_aux = rep(near_fine_cov_aux, n_t)

switch = 1					
if (max(near_fine_cov_aux)==0) {	
	row_ind_8_aux = row_ind_cur+k
	col_ind_8_aux = 1
	near_fine_cov_aux = 0
	switch = 0
}
if (switch==1) {
	row_ind_8_aux = (rep(row_ind_cur+k, n_tot))[near_fine_cov_aux!=0]
	col_ind_8_aux = (1:n_tot)[near_fine_cov_aux!=0]
	near_fine_cov_aux = near_fine_cov_aux[near_fine_cov_aux!=0]
}
					
					#row_ind_8_aux = (rep(row_ind_cur+k, n_tot))[near_fine_cov_aux!=0]
					#col_ind_8_aux = (1:n_tot)[near_fine_cov_aux!=0]
					#near_fine_cov_aux = near_fine_cov_aux[near_fine_cov_aux!=0]
					row_ind_8 = c(row_ind_8, row_ind_8_aux)
					col_ind_8 = c(col_ind_8, col_ind_8_aux)
					near_fine_vals_8 = c(near_fine_vals_8, near_fine_cov_aux)
					k = k+1		
				}
			}
		}	
		bvec_8 = bvec_8[-1]
		row_ind_8 = row_ind_8[-1]
		col_ind_8 = col_ind_8[-1]
		near_fine_vals_8 = near_fine_vals_8[-1]
		vec_n_cats_near_fine_covs = vec_n_cats_near_fine_covs[-1]
		row_ind_cur	= max(row_ind_8)
	}
	
	if (!is.null(use_controls_mat)) {		
		col_ind_9 = NA
		row_ind_9 = NA
		use_controls_vals_9 = NA
		for (i in 1:ncol(use_controls_mat)) {
			use_controls = use_controls_mat[, i]
			use_controls = use_controls[(n_t+1):(n_t+n_c)]
			use_controls_aux = rep(use_controls, n_t)
			
			col_ind_9 = c(col_ind_9, (1:n_tot)[use_controls_aux==1])
			row_ind_9 = c(row_ind_9, rep(row_ind_cur+i, length((1:n_tot)[use_controls_aux==1])))
			use_controls_vals_9 = c(use_controls_vals_9, rep(1, length((1:n_tot)[use_controls_aux==1])))
			
			if (i==1) {
				
			}
		}
		col_ind_9 = col_ind_9[-1]
		row_ind_9 = row_ind_9[-1]
		use_controls_vals_9 = use_controls_vals_9[-1]
	}
	
	row_ind = c(row_ind_1, row_ind_2)
	col_ind = c(col_ind_1, col_ind_2)
	vals = c(ones_1, ones_2)
	if (!is.null(mom_ks_covs)) {
		row_ind = c(row_ind, row_ind_3.4)
		col_ind = c(col_ind, col_ind_3.4)
		vals = c(vals, mom_ks_vals_3.4)
	}
	if (!is.null(exact_covs)) {
		row_ind = c(row_ind, row_ind_5)
		col_ind = c(col_ind, col_ind_5)
		vals = c(vals, exact_vals_5)
	}
	if (!is.null(near_exact_covs)) {
		row_ind = c(row_ind, row_ind_6)
		col_ind = c(col_ind, col_ind_6)
		vals = c(vals, near_exact_vals_6)
	}
	if (!is.null(fine_covs)) {
		row_ind = c(row_ind, row_ind_7)
		col_ind = c(col_ind, col_ind_7)
		vals = c(vals, fine_vals_7)
	}
	if (!is.null(near_fine_covs)) {
		row_ind = c(row_ind, row_ind_8)
		col_ind = c(col_ind, col_ind_8)
		vals = c(vals, near_fine_vals_8)
	}
	if (!is.null(use_controls_mat)) {
		row_ind = c(row_ind, row_ind_9)
		col_ind = c(col_ind, col_ind_9)
		vals = c(vals, use_controls_vals_9)	
	}
	
	aux = cbind(row_ind, col_ind, vals)[order(col_ind), ]
	cnstrn_mat = simple_triplet_matrix(i = aux[, 1], j = aux[, 2], v = aux[, 3])
			
	return(list(cnstrn_mat = cnstrn_mat, bvec_7 = bvec_7, bvec_8 = bvec_8, vec_n_cats_near_fine_covs = vec_n_cats_near_fine_covs))
	
}


